import serial
import time
import csv
import matplotlib.pyplot as plt
from collections import deque

# --- CONFIGURACIÓN ---
puerto = 'COM7'  # Cambia esto si tu puerto cambia
baudios = 9600
duracion = 5 * 60  # 5 minutos
archivo_csv = "ecg_datos.csv"
ventana_tiempo = 5  # segundos visibles en la gráfica
muestras_por_segundo = 1000
ventana_muestras = ventana_tiempo * muestras_por_segundo

# --- INICIALIZACIÓN ---
arduino = serial.Serial(puerto, baudios, timeout=1)
print("Esperando a que Arduino se conecte...")
time.sleep(2)

# Buffers para gráfica en tiempo real
valores_ecg = deque([0]*ventana_muestras, maxlen=ventana_muestras)
tiempos = deque([0]*ventana_muestras, maxlen=ventana_muestras)

# Listas para guardar todos los datos completos
datos_ecg = []
datos_tiempo = []

# --- Setup de la gráfica en tiempo real ---
plt.ion()
fig, ax = plt.subplots()
linea, = ax.plot(tiempos, valores_ecg)
ax.set_ylim(0, 1023)
ax.set_title("Señal ECG en tiempo real")
ax.set_xlabel("Tiempo (s)")
ax.set_ylabel("Valor ECG")

# --- Inicio de adquisición ---
tiempo_inicio = time.time()
print("Adquiriendo datos...")

while time.time() - tiempo_inicio < duracion:
    try:
        dato = arduino.readline().decode().strip()
        if dato.isdigit():
            valor = int(dato)
            tiempo_actual = time.time() - tiempo_inicio

            # Guardar en buffers para gráfica en tiempo real
            valores_ecg.append(valor)
            tiempos.append(tiempo_actual)

            # Guardar en listas completas
            datos_ecg.append(valor)
            datos_tiempo.append(tiempo_actual)

            # Actualizar gráfica
            linea.set_xdata(tiempos)
            linea.set_ydata(valores_ecg)
            ax.set_xlim(max(0, tiempo_actual - ventana_tiempo), tiempo_actual)
            plt.pause(0.001)

    except Exception as e:
        print(f"Error al leer dato: {e}")

arduino.close()
print("✅ Adquisición finalizada.")

# --- Guardar todos los datos en CSV ---
with open(archivo_csv, mode='w', newline='') as archivo:
    writer = csv.writer(archivo)
    writer.writerow(["Tiempo (s)", "Valor ECG"])
    for t, v in zip(datos_tiempo, datos_ecg):
        writer.writerow([t, v])

print(f"✅ Datos guardados en {archivo_csv}")

# --- Guardar y mostrar gráfica completa ---
plt.ioff()
plt.figure(figsize=(10, 4))
plt.plot(datos_tiempo, datos_ecg, color='blue')
plt.title("Señal ECG completa (5 minutos)")
plt.xlabel("Tiempo (s)")
plt.ylabel("Valor ECG")
plt.grid(True)
plt.tight_layout()
plt.savefig("ecg_completo.png")
plt.show()
print("📈 Gráfica guardada como ecg_completo.png")
